package Test;           // must be the first line

import java.util.*;
import bank.*;                  // Package created by ourselfs
// OR
// import Packages.bank.*;

public class test {
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);        // part of util package

        // Create an empty account, bcz we import package bank
        Account obj = new Account();        // part of bank package

        // Deposit money
        System.out.println("Enter the amount that you want to deposit: ");
        double deposit_amount = in.nextDouble();
        obj.deposit(deposit_amount);

        // print current balance
        System.out.println("Current balance after deposit the amount: " + obj.getBalance());


        // Withdraw money
        System.out.println("Enter the amount that you want to withdraw: ");
        double withdraw_amount = in.nextDouble();
        obj.withdraw(withdraw_amount);

        // print remaining balance
        System.out.println("Remaining balance after withdrawing the amount: " + obj.getBalance());

        in.close();
    }
}
