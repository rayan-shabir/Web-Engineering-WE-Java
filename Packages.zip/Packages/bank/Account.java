package bank;
import java.util.*;

/*
REMEMBER :: (IMPT) 
* Whenever we compile our package file (A Java file which contains package), it's name will be converted / chnaged into complete qualified name.
Thus, 
After compiling, name will be changed   ->  complete qualified name.
                                            package-name.class-name

Account                         -->         bank.Account

So, for running if we do not write complete qualified name, we will got an ERROR : "java.lang.NoClassDefFoundError: bank/Account (wrong name: Account)"

And to run this newly qualified named file we must have to go back (cd .. in cmd prompt) at the place from where our package starts. (bcz now the folder / package name is part of complete qualified name). So we have to go there from where this name starts (this package starts).

=> Means for compile we have to be inside the package where file exits. Only then our code will compiled.
And for running we have to be outside the package, means to go there (move our control) from where our package starts. Only then our code will run.

*/

public class Account {
    public double balance;

    public void deposit(double amount) {
        balance += amount;
    }

    public double withdraw(double amount) {
        // See if the amount can be withdrawn
        if(amount <= balance) {
            balance -= amount;
            return amount;
        } else
            // withdrawl not allowed
            return 0.0;
    }

    public double getBalance() {
        return this.balance;
    }

    

    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);

        Account obj = new Account(); //creating an empty account

        // Deposit money
        System.out.println("Enter the amount that you want to deposit: ");
        double deposit_amount = in.nextDouble();
        obj.deposit(deposit_amount);

        // print current balance
        System.out.println("Current balance after deposit the amount: " + obj.getBalance());

        in.close();
    }
}