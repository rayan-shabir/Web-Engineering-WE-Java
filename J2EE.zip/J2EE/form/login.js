function clearErrors() {

    errors = document.getElementsByClassName('formerror');
    for (let item of errors) {
        item.innerHTML = "";
    }
}

function seterror(id, error) {
    //sets error inside tag of id 
    element = document.getElementById(id);
    element.getElementsByClassName('formerror')[0].innerHTML = error;

}

function validateForm() {
    var returnval = true;
    clearErrors();

    var email = document.forms['myForm']["email"].value;


    if (email.length < 5) {
        seterror("email", "*Length of email is too short");
        document.myForm.email.focus();
        returnval = false;
    }

    var at_loc = email.indexOf("@");
    var dot_loc = email.indexOf(".");

    var at_dot_str = email.substring(at_loc);
    var at_dot = at_dot_str.indexOf(".");
    // var at_dot = email.lastindexOf(".");

    if (at_loc <= 0 || (at_loc + 1) == (dot_loc) || dot_loc == (at_loc - 1) || dot_loc == email.length - 1 || at_loc == (email.length - 1) || dot_loc <= 0) {
        seterror("email", "**Email is not correct!");
        document.myForm.email.focus();
        returnval = false;
    }

    // if (at_dot != dot_loc) {
    //     if (at_loc <= 0 || at_loc + 1 == at_dot || dot_loc == (at_loc - 1) || at_dot == email.length - 1 || at_loc == (email.length - 1) || dot_loc + 1 == at_dot || at_dot <= 0 || dot_loc <= 0) {
    //         seterror("email", "*Email is not correct!");
    //         document.myForm.email.focus();
    //         returnval = false;
    //     }
    // } else if (at_dot == dot_loc) {
    //     if ((at_loc+1) == (dot_loc) || at_loc <= 0  || dot_loc == (at_loc - 1) || dot_loc == email.length - 1 || at_loc == (email.length - 1) || at_dot <= 0) {
    //         seterror("email", "**Email is not correct!");
    //         document.myForm.email.focus();
    //         returnval = false;
    //     }
    // }


    if (email.length == 0) {
        seterror("email", "*Length of email cannot be zero!");
        document.myForm.email.focus();
        returnval = false;
    }

    if (email.length > 15) {
        seterror("email", "*Email length is too long!");
        document.myForm.email.focus();
        returnval = false;
    }



    var password = document.myForm.pass.value;


    var passw = "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/";
    // if(password.match(passw)) {
    //     seterror("pass", "*Password must contain atleast one upper case & one lower case character & a digit!");
    //     document.myForm.email.focus();
    //     returnval = false;
    // }

    if (password.length < 6) {

        // Quiz: create a logic to allow only those passwords which contain atleast one letter, one number and one special character and one uppercase letter
        seterror("pass", "*Password should be atleast 6 characters long!");
        document.myForm.email.focus();
        returnval = false;
    }





    return returnval;
}